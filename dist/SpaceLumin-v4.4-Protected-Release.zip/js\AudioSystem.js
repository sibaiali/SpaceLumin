/*! © 2026 Lumin Flow Studios. All Rights Reserved. Proprietary & Confidential (AudioSystem.js) | Seal: LFS-2026-9F8A4D2C-7E1B63A0-SPACELUMIN-V43-SEAL */
*/
*/
class AudioSystem {
constructor() {
this.ready = false;
this.musicOn = true;
this.sfxOn = true;
this.hapticsOn = true;
this.masterVolume = 1.0;
this.maxVoices = 6;
this.activeVoices = [];
this.priority = {
playerDamage: 100,
kill: 80,
laser: 60,
hitTick: 40,
collect: 30,
ambience: 10
};
this.sounds = {};
this.ambPad = null;
this.ambFilter = null;
this.kickSynth = null;
this.radioSignal = null;
this.radioFilter = null;
this.lastRadioSignal = 0;
this.lastKick = 0;
this.lastMusicPulse = 0;
}
async init() {
if (this.ready) return;
try {
await Tone.start();
this.sounds.collect = new Tone.PolySynth().toDestination();
this.sounds.error = new Tone.PolySynth().toDestination();
this.sounds.shoot = new Tone.PolySynth().toDestination();
this.sounds.decoy = new Tone.NoiseSynth().toDestination();
this.sounds.spawn = new Tone.PolySynth().toDestination();
this.sounds.levelUp = new Tone.PolySynth().toDestination();
this.sounds.reaper = new Tone.MembraneSynth().toDestination();
this.sounds.hover = new Tone.PolySynth().toDestination();
this.sounds.freeze = new Tone.MetalSynth().toDestination(); // Ice crack
this.sounds.impact = new Tone.MembraneSynth().toDestination(); // Impact glow
this.sounds.whoosh = new Tone.NoiseSynth({
noise: { type: 'pink' },
envelope: { attack: 0.01, decay: 0.3, sustain: 0, release: 0.2 }
}).toDestination(); // Flyby whoosh
this.sounds.alienApproach = new Tone.FMSynth({
harmonicity: 3,
modulationIndex: 10,
envelope: { attack: 0.5, decay: 0.2, sustain: 0.3, release: 0.5 }
}).toDestination(); // Alien incoming
this.sounds.chargeHiss = new Tone.NoiseSynth({
noise: { type: 'white' },
envelope: { attack: 0.05, decay: 0.3, sustain: 0.2, release: 0.1 }
}).toDestination();
this.kickSynth = new Tone.MembraneSynth().toDestination();
this.vacuumFilter = new Tone.Filter({
type: 'lowpass',
frequency: 400,      // Cut high frequencies
rolloff: -24,        // Steep rolloff
Q: 0.5
}).toDestination();
this.sounds.impact.disconnect();
this.sounds.impact.connect(this.vacuumFilter);
this.vacuumExplosion = new Tone.MembraneSynth({
pitchDecay: 0.1,
octaves: 3,
envelope: { attack: 0.001, decay: 0.4, sustain: 0.01, release: 0.6 }
}).connect(this.vacuumFilter);
this.vacuumExplosion.volume.value = -8;
const reverb = new Tone.Reverb(6).toDestination();
this.ambFilter = new Tone.AutoFilter("4n").connect(reverb);
this.ambPad = new Tone.PolySynth().connect(this.ambFilter);
this.ambPad.volume.value = -26;
this.ambFilter.baseFrequency = 80;
this.ambFilter.octaves = 2;
this.ambFilter.start();
const droneReverb = new Tone.Reverb(10).toDestination();
this.spaceDrone = new Tone.Synth({
oscillator: { type: 'sine' },
envelope: { attack: 2, decay: 1, sustain: 0.8, release: 3 }
}).connect(droneReverb);
this.spaceDrone.volume.value = -35;
Tone.Transport.start();
this.updateVolumes();
this.ambPad.triggerAttackRelease(["C3", "G3", "D4"], "4n");
this.lastDroneTime = 0;
this.ready = true;
} catch (e) {
console.warn("Audio init failed:", e);
}
}
updateVolumes() {
if (!this.sounds.collect) return;
const sfxVol = this.sfxOn ? -12 : -60;
const musicVol = this.musicOn ? -12 : -60;
this.sounds.collect.volume.value = sfxVol;
this.sounds.error.volume.value = sfxVol + 2;
this.sounds.shoot.volume.value = sfxVol - 6;
this.sounds.decoy.volume.value = sfxVol - 4;
this.sounds.spawn.volume.value = sfxVol - 2;
this.sounds.levelUp.volume.value = sfxVol + 4;
this.sounds.reaper.volume.value = sfxVol + 6;
this.sounds.hover.volume.value = sfxVol - 12;
if (this.kickSynth) this.kickSynth.volume.value = musicVol;
if (this.ambPad) this.ambPad.volume.value = this.musicOn ? -26 : -60;
}
setMusicOn(on) {
this.musicOn = on;
this.updateVolumes();
}
setSfxOn(on) {
this.sfxOn = on;
this.updateVolumes();
}
setHapticsOn(on) {
this.hapticsOn = on;
}
setMasterVolume(vol) {
this.masterVolume = Math.max(0, Math.min(1, vol));
if (typeof Tone !== 'undefined' && Tone.Destination) {
const db = this.masterVolume <= 0.01 ? -60 : 20 * Math.log10(this.masterVolume);
Tone.Destination.volume.rampTo(db, 0.1);
}
}
mute() {
this._prevMasterVol = this.masterVolume;
this.setMasterVolume(0);
}
unmute() {
this.setMasterVolume(this._prevMasterVol ?? 1.0);
}
playPowerup(note = "C5") {
if (!this.ready || !this.sfxOn) return;
if (this.sounds.levelUp) {
this.sounds.levelUp.triggerAttackRelease([note, "G5"], "8n");
}
}
playExplode(note = "C2") {
this.playVacuumExplosion(note);
}
playCollect(note = "C4") {
if (!this.ready || !this.sfxOn) return;
this.sounds.collect.triggerAttackRelease(note, "16n");
}
playError(note = "G2") {
if (!this.ready || !this.sfxOn) return;
this.sounds.error.triggerAttackRelease(note, "8n");
}
playShoot() {
if (!this.ready || !this.sfxOn) return;
this.sounds.shoot.triggerAttackRelease("C4", "16n");
}
playDecoy() {
if (!this.ready || !this.sfxOn) return;
this.sounds.decoy.triggerAttackRelease("16n");
}
playSpawn(note = "C3") {
if (!this.ready || !this.sfxOn) return;
this.sounds.spawn.triggerAttackRelease(note, "16n");
}
playLevelUp() {
if (!this.ready || !this.sfxOn) return;
this.sounds.levelUp.triggerAttackRelease(["C4", "G4", "C5"], "8n");
}
playReaper(note = "A1") {
if (!this.ready || !this.sfxOn) return;
this.sounds.reaper.triggerAttackRelease(note, "2n");
}
playHover() {
if (!this.ready || !this.sfxOn) return;
this.sounds.hover.triggerAttackRelease("C6", "32n", undefined, 0.1);
}
playFreeze() {
if (!this.ready || !this.sfxOn) return;
this.sounds.freeze.triggerAttackRelease("C2", "4n");
setTimeout(() => {
if (this.sounds.freeze) this.sounds.freeze.triggerAttackRelease("G1", "8n");
}, 100);
}
playImpact() {
if (!this.ready || !this.sfxOn) return;
this.sounds.impact.triggerAttackRelease("G2", "8n");
}
playVacuumExplosion(note = "C2") {
if (!this.ready || !this.sfxOn) return;
if (this.vacuumExplosion) {
this.vacuumExplosion.triggerAttackRelease(note, "4n");
}
}
playWhoosh() {
if (!this.ready || !this.sfxOn) return;
this.sounds.whoosh.triggerAttackRelease("8n");
}
playAlienApproach() {
if (!this.ready || !this.sfxOn) return;
this.sounds.alienApproach.triggerAttackRelease("A2", "4n");
}
playChargeHiss() {
if (!this.ready || !this.sfxOn) return;
if (this.sounds.chargeHiss) {
this.sounds.chargeHiss.triggerAttackRelease("8n");
}
}
playSound(name) {
if (!this.ready || !this.sfxOn) return;
const soundMap = {
'charge_hiss': () => this.playChargeHiss(),
'collect': () => this.playCollect(),
'error': () => this.playError(),
'shoot': () => this.playShoot(),
'decoy': () => this.playDecoy(),
'spawn': () => this.playSpawn(),
'level_up': () => this.playLevelUp(),
'reaper': () => this.playReaper(),
'hover': () => this.playHover(),
'freeze': () => this.playFreeze(),
'impact': () => this.playImpact(),
'whoosh': () => this.playWhoosh(),
'alien_approach': () => this.playAlienApproach()
};
if (soundMap[name]) {
soundMap[name]();
}
}
playSpaceDrone(time) {
if (!this.ready || !this.musicOn) return;
if (time - this.lastDroneTime > 15) {
this.lastDroneTime = time;
const notes = ["C1", "G1", "D1", "A1"];
const note = notes[Math.floor(Math.random() * notes.length)];
this.spaceDrone.triggerAttackRelease(note, "4n");
}
}
pulseMusic(time, dayPhase, isBoss, combo) {
if (!this.ready || !this.musicOn) return;
if (time - this.lastKick > 0.6) {
this.kickSynth.triggerAttackRelease("C1", "8n");
this.lastKick = time;
}
if (time - this.lastMusicPulse < 7) return;
this.lastMusicPulse = time;
let notes;
if (isBoss) {
notes = ["F2", "C3", "G3"];
} else if (dayPhase < 0.5) {
notes = ["C3", "E3", "G3", "B3"];
} else {
notes = ["A2", "D3", "E3", "G3"];
}
this.ambPad.triggerAttackRelease(notes, "2n");
if (combo >= 3) {
setTimeout(() => this.playCollect("C5"), 100);
setTimeout(() => this.playCollect("E5"), 200);
}
}
setFlowState(flowCritical) {
if (!this.ambFilter) return;
const cutoff = flowCritical ? 300 : 2000;
this.ambFilter.frequency.rampTo(cutoff, 0.1);
}
playSectorStart() {
if (!this.ready || !this.sfxOn) return;
if (this.sounds.collect) {
this.sounds.collect.triggerAttackRelease(["C3", "E3", "G3"], "8n");
setTimeout(() => this.sounds.collect.triggerAttackRelease(["C4", "E4", "G4"], "4n"), 150);
}
}
playBossSpawn() {
if (!this.ready || !this.sfxOn) return;
if (this.sounds.reaper) {
this.sounds.reaper.triggerAttackRelease("E1", "2n");
setTimeout(() => this.sounds.reaper.triggerAttackRelease("G1", "2n"), 300);
setTimeout(() => this.sounds.reaper.triggerAttackRelease("A1", "2n"), 600);
}
}
playBlackHole() {
if (!this.ready || !this.sfxOn) return;
if (this.spaceDrone) {
this.spaceDrone.triggerAttackRelease("C1", "4n");
setTimeout(() => this.spaceDrone.triggerAttackRelease("G0", "2n"), 500);
}
if (this.sounds.whoosh) {
this.sounds.whoosh.triggerAttackRelease("4n");
}
}
playRadioSignal() {
if (!this.ready || !this.sfxOn) return;
if (this.sounds.collect) {
const notes = ["A5", "C6", "E5", "G5"];
const note = notes[Math.floor(Math.random() * notes.length)];
this.sounds.collect.triggerAttackRelease(note, "32n");
setTimeout(() => this.sounds.collect.triggerAttackRelease(note, "32n"), 80);
setTimeout(() => this.sounds.collect.triggerAttackRelease(note, "32n"), 160);
}
}
playKillBurst() {
if (!this.ready || !this.sfxOn) return;
if (this.sounds.impact) {
this.sounds.impact.triggerAttackRelease("C3", "16n");
}
}
haptic(kind) {
if (!this.hapticsOn || !navigator.vibrate) return;
try {
if (kind === 'light') navigator.vibrate(20);
else if (kind === 'medium') navigator.vibrate(50);
else if (kind === 'heavy') navigator.vibrate([80, 30, 80]);
} catch (e) {
}
}
dispose() {
if (this.ambPad) this.ambPad.dispose();
if (this.ambFilter) this.ambFilter.dispose();
if (this.kickSynth) this.kickSynth.dispose();
Object.values(this.sounds).forEach(s => {
if (s && s.dispose) s.dispose();
});
}
}
